#include "Lexer.h"
#include <algorithm>
#include <iostream>
#include <math.h>


Lexer::Lexer()
{
    mySource = nullptr;
    currentToken = nullptr;
}

void Lexer::loadStandardOperatorsSeparators()
{
    predefinedSymbols.addOperator("+");
    predefinedSymbols.addOperator("-");
    predefinedSymbols.addOperator("*");
    predefinedSymbols.addOperator("/");
    predefinedSymbols.addOperator("[");
    predefinedSymbols.addOperator("]");
    predefinedSymbols.addOperator(".");
    predefinedSymbols.addOperator("==");
    predefinedSymbols.addOperator(">");
    predefinedSymbols.addOperator("<");
    predefinedSymbols.addOperator(">=");
    predefinedSymbols.addOperator("<=");
    predefinedSymbols.addOperator("!=");
    predefinedSymbols.addOperator("!");

    predefinedSymbols.addSeparator(";");
    predefinedSymbols.addSeparator("(");
    predefinedSymbols.addSeparator(")");
    predefinedSymbols.addSeparator("{");
    predefinedSymbols.addSeparator("}");
    predefinedSymbols.addSeparator(",");
}

void Lexer::setSource(Source* newSource)
{
    mySource = newSource;
}

void Lexer::produceToken()
{
    skipWhiteSpacesAndComments();

    char currentChar = mySource->getCurrentChar();
    
    if (isalpha(currentChar))
        produceIdentifier();
    else if (isdigit(currentChar))
        produceNumber();
    else if (isOperatorSeparator(currentChar))
        produceOperatorSeparator();
    else
        produceSpecial();
}

void Lexer::skipWhiteSpacesAndComments()
{   
    char currChar = mySource->getCurrentChar();
    while (isspace(currChar) || currChar == '#')    // komentarze zaczynaj� si� i ko�cz� '#'
    {
        if (currChar != '#')
        {
            mySource->processOneChar();
            currChar = mySource->getCurrentChar();
        }
        else
        {
            do {
                mySource->processOneChar();
            } while ( ( mySource->getCurrentChar() != '#') && !( mySource->isEndOfInput() ) );  // na wypadek, jakby kto� nie zamnk�� komentarza
        }
    }
}

void Lexer::produceIdentifier()
{
    std::string result = "";
    char tempChar = mySource->getCurrentChar();
    int overflowControler = 0;

    do {
        result += tempChar;
        mySource->processOneChar();
        tempChar = mySource->getCurrentChar();
        
        ++overflowControler;
        if (overflowControler > MAX_IDENTIFIER_LENGTH)
        {
            currentToken = new UnsafeToken();
            return;
        }

    } while ( isalnum(tempChar) || tempChar == '_');

    if (predefinedSymbols.isKeyword(result))
        currentToken = new KeywordToken(result);
    else
        currentToken = new IdentifierToken(result);
}

void Lexer::produceNumber()
{
    int integerPart = parseSingleNumberFromSource();

    if (mySource->getCurrentChar() == '.' && isdigit( mySource->getNextChar() ) )
    {
        mySource->processOneChar();
        int fractionalPart = parseSingleNumberFromSource();
        int length = floor(log10((float)fractionalPart)) + 1;
        double x = fractionalPart / pow(10, length);
        currentToken = new FloatToken( (double) integerPart + x);
    }
    else
        currentToken = new IntToken(integerPart);

    return;
}

int Lexer::parseSingleNumberFromSource()
{
    int result = 0;
    char tempChar = mySource->getCurrentChar();

    do {
        if (result < INT_MAX)
            result = result * 10 + ((int)tempChar - (int)'0');
        mySource->processOneChar();
        tempChar = mySource->getCurrentChar();
    } while (isdigit(tempChar));

    return result;
}

void Lexer::produceOperatorSeparator()
{
    char currChar = mySource->getCurrentChar();

    if (predefinedSymbols.isBeginningOfOperator(currChar))  // czyli operator
    {
        std::string operatorValue = "" + currChar;
        mySource->processOneChar();
        
        currChar = mySource->getCurrentChar();
        if (predefinedSymbols.isEndOfOperator(currChar))
        {
            operatorValue += currChar;
            mySource->processOneChar();
        }

        currentToken = new OperatorToken(operatorValue);
    }
    else    // czyli separator
    {
        currentToken = new SeparatorToken(currChar);
        mySource->processOneChar();
    }
}

void Lexer::produceSpecial()
{
    if (mySource->isEndOfInput())
    {
        currentToken = new EOTToken();
    }
    else {
        mySource->processOneChar();
        currentToken = new InvalidToken();
    }
}

bool Lexer::isOperatorSeparator(char charToCheck)
{
    if (predefinedSymbols.isBeginningOfOperator(charToCheck) || predefinedSymbols.isSeparator(charToCheck))
        return true;
    else
        return false;
}

Token* Lexer::nextToken()
{
    if (mySource != nullptr)
        produceToken();
    else
        currentToken = new InvalidToken();

    return currentToken;
}

SymbolTable* Lexer::getSymbolTable()
{
    return &predefinedSymbols;
}
