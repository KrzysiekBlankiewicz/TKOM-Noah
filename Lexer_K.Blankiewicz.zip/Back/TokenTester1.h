#pragma once
//#include "Token.h"

class Token;
class IdentifierToken;
class KeywordToken;
class OperatorToken;
class SeparatorToken;
class IntToken;
class FloatToken;
class EOTToken;
class InvalidToken;
class UnsafeToken;


// Klasa wizytatora Tokenu i jego pochodnych
// S�u�y okre�leniu typu tokenu

class TokenTester
{
public:

	int visit(Token* host);
	int visit(IdentifierToken* host);
	int visit(KeywordToken* host);
	int visit(OperatorToken* host);
	int visit(SeparatorToken* host);
	int visit(IntToken* host);
	int visit(FloatToken* host);
	int visit(EOTToken* host);
	int visit(InvalidToken* host);
	int visit(UnsafeToken* host);

	static const int IDENTIFIER = 0;
	static const int KEYWORD = 1;
	static const int OPERATOR = 2;
	static const int SEPARATOR = 3;
	static const int INT = 4;
	static const int FLOAT = 5;
	static const int EOT = 6;
	static const int INVALID = 7;
	static const int UNSAFE = 8;
	static const int UNKNOWN = 9;
};