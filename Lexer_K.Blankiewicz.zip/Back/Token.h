#pragma once
#include <string>
#include "TokenTester1.h"

class TokenTester;

class Token
{
public:
	virtual int accept(TokenTester* tester);
};

class IdentifierToken : public Token
{
	std::string value;
	//int symbolTableId;
public:
	IdentifierToken(std::string v/*, int id*/);
	virtual int accept(TokenTester* tester);

};

class KeywordToken : public Token
{
	std::string value;
public:
	KeywordToken(std::string v);
	virtual int accept(TokenTester* tester);
};

class OperatorToken : public Token
{
	std::string value;
public:
	OperatorToken(std::string v);
	virtual int accept(TokenTester* tester);
};

class SeparatorToken : public Token
{
	char value;
public:
	SeparatorToken(char v);
	virtual int accept(TokenTester* tester);
};

class IntToken : public Token
{
	int value;
public:
	IntToken(int v);
	virtual int accept(TokenTester* tester);
};

class FloatToken : public Token
{
	double value;
public:
	FloatToken(double v);
	virtual int accept(TokenTester* tester);
};

class EOTToken : public Token
{
public:
	EOTToken();
	virtual int accept(TokenTester* tester);
};

class InvalidToken : public Token
{
public:
	InvalidToken();
	virtual int accept(TokenTester* tester);
};

class UnsafeToken : public Token
{
public:
	UnsafeToken();
	virtual int accept(TokenTester* tester);
};

