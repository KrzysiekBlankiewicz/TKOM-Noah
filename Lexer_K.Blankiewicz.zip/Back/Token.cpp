#include "Token.h"

int Token::accept(TokenTester* tester)
{
	return tester->visit(this);
}


IdentifierToken::IdentifierToken(std::string v/*, int id*/)
{
	value = v;
	//symbolTableId = id;
}

int IdentifierToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

KeywordToken::KeywordToken(std::string v)
{
	value = v;
}

int KeywordToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

OperatorToken::OperatorToken(std::string v)
{
	value = v;
}

int OperatorToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

SeparatorToken::SeparatorToken(char v)
{
	value = v;
}

int SeparatorToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

IntToken::IntToken(int v)
{
	value = v;
}

int IntToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

FloatToken::FloatToken(double v)
{
	value = v;
}

int FloatToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

EOTToken::EOTToken()
{

}

int EOTToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

InvalidToken::InvalidToken()
{

}

int InvalidToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}

UnsafeToken::UnsafeToken()
{
}

int UnsafeToken::accept(TokenTester* tester)
{
	return tester->visit(this);
}








