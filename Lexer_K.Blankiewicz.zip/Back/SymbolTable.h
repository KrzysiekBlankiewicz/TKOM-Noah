#pragma once
#include <set>
#include <string>


class SymbolTable
{
	// Zak�adam, �e: operatory s� jedno- lub dwuznakowe
	// Zak�adam, �e separatory s� jednoznakowe
	// Dla d�u�szych, dalsza ich cz�� zostanie potraktowana jak osobne tokeny

	std::set<std::string> keywords;
	std::set<std::string> operators;
	std::set<std::string> separators;

	std::set<char> firstCharsOfOperators;
	std::set<char> secondCharsOfOperators;

public:
	bool isOperator(std::string stringToCheck);
	bool isSeparator(std::string stringToCheck);
	bool isSeparator(char charToCheck);
	bool isKeyword(std::string stringToCheck);
	bool isBeginningOfOperator(char charToCheck);
	bool isEndOfOperator(char charToCheck);

	void addKeyword(std::string newKeyword);
	void addOperator(std::string newOpertaor);
	void addSeparator(std::string newSeparator);
};
