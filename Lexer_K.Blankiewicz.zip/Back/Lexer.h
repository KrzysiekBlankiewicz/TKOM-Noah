#pragma once
#include "Token.h"
#include "Source.h"
#include <vector>
#include <set>
#include "SymbolTable.h"

class Lexer
{
	Token* currentToken;
	Source* mySource;

	SymbolTable predefinedSymbols;

	//metoda z "g��wnym switchem":
	void produceToken();
	
	//metody tworz�ce odpowiedni token:
	void produceIdentifier();
	void produceNumber();
	void produceOperatorSeparator();
	void produceSpecial();

	//pomocnicze:
	void skipWhiteSpacesAndComments();
	bool isOperatorSeparator(char charToCheck);
	int parseSingleNumberFromSource();

	const int MAX_IDENTIFIER_LENGTH = 50;	// TODO docelowo z pliku konfiguracyjnego

public:
	Lexer();
	void loadStandardOperatorsSeparators();
	void setSource(Source* newSource);

	// metoda wo�ana przez parser:
	Token* nextToken();

	// tablica symboli:
	SymbolTable* getSymbolTable();

};
