#include "SymbolTable.h"

bool SymbolTable::isOperator(std::string stringToCheck)
{
    if ( std::find(operators.begin(), operators.end(), stringToCheck) != operators.end() )
        return true;
    else
        return false;
}

bool SymbolTable::isSeparator(std::string stringToCheck)
{
    if (std::find(separators.begin(), separators.end(), stringToCheck) != separators.end())
        return true;
    else
        return false;
}

bool SymbolTable::isSeparator(char charToCheck)
{
    std::string s = "";
    s += charToCheck;
    return isSeparator(s);
}

bool SymbolTable::isKeyword(std::string stringToCheck)
{
    if (std::find(keywords.begin(), keywords.end(), stringToCheck) != keywords.end())
        return true;
    else
        return false;
}

bool SymbolTable::isBeginningOfOperator(char charToCheck)
{
    if (std::find(firstCharsOfOperators.begin(), firstCharsOfOperators.end(), charToCheck) != firstCharsOfOperators.end())
        return true;
    else
        return false;
}

bool SymbolTable::isEndOfOperator(char charToCheck)
{
    if (std::find(secondCharsOfOperators.begin(), secondCharsOfOperators.end(), charToCheck) != secondCharsOfOperators.end())
        return true;
    else
        return false;
}

void SymbolTable::addKeyword(std::string newKeyword)
{
    keywords.insert(newKeyword);
}

void SymbolTable::addOperator(std::string newOpertaor)
{
    if (newOpertaor.length() > 0)
    {
        operators.insert(newOpertaor);
        firstCharsOfOperators.insert(newOpertaor[0]);
        
        if (newOpertaor.length() == 2)
            secondCharsOfOperators.insert(newOpertaor[1]);
    }
}

void SymbolTable::addSeparator(std::string newSeparator)
{
    if (newSeparator.length() > 0)
    {
        separators.insert(newSeparator);
    }
}
